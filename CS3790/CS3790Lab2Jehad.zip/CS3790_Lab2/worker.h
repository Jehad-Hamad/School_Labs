#ifndef WORKER_H
#define WORKER_H

#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

void primes(int, int);
int fileOrPrint(int, int, int);
ostringstream oss;

#endif